package edu.unac.exception;

public class ConsecutiveCharacterException extends Exception {
    public ConsecutiveCharacterException(String message) {
        super(message);
    }
}
