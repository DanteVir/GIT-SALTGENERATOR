package edu.unac.exception;

public class InvalidLengthException extends Exception {
    public InvalidLengthException(String message) {
        super(message);
    }
}
