package edu.unac.exception;

public class RepeatedCharacterException extends Exception {
    public RepeatedCharacterException(String message) {
        super(message);
    }
}

